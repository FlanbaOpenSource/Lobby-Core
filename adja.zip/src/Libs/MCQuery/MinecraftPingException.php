<?php

declare(strict_types=1);

namespace Libs\MCQuery;

use Exception;

class MinecraftPingException extends Exception
{
}