<?php

namespace DidntPot\npc;

use DidntPot\forms\types\bridge\PlayBridgeForm;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use sergittos\flanbacore\FlanbaCore;
use xenialdan\skinapi\API;

class BridgeNPC extends Human {

    protected $gravity = 0.0;

    public function onInteract(Player $player, Vector3 $clickPos): bool
    {
        $player->sendForm(new PlayBridgeForm());
        return true;
    }

    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);

        $yes = fopen(FlanbaCore::getInstance()->getDataFolder() . 'bridge.png', 'r');
        $this->setSkin(new Skin('vobs', API::fromImage($yes)));
    }



}