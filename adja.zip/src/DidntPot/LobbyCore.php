<?php

namespace DidntPot;

use DidntPot\npc\BridgeNPC;
use DidntPot\player\PlayerListener;
use DidntPot\utils\BasicUtils;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use sergittos\flanbacore\FlanbaCore;
use xenialdan\skinapi\API;

class LobbyCore extends PluginBase
{
    // Free getInstance() method!
    use SingletonTrait;

    /**
     * @return void
     */
    public function onLoad(): void
    {
        self::setInstance($this);
    }

    /**
     * @return void
     */
    public function onEnable(): void
    {
        $yes = fopen(FlanbaCore::getInstance()->getDataFolder() . 'bridge.png', 'r');
        $skin = new Skin('vobs', API::fromImage($yes));
        $bridg = new BridgeNPC(new Location("235", '15', "-203", BasicUtils::getLobbyWorld(), 1, 1), $skin);
        $bridg->spawnToAll();

        // Shouldn't really happen but just in case.
        if (is_null(self::$instance)) {
            $this->getLogger()->critical("LobbyCore instance is NULL, disabling the plugin.");
            $this->getServer()->shutdown();
        }

        $doesLoad = BasicUtils::loadLobbyWorld();
        if ($doesLoad === false) {
            $this->getLogger()->critical("The lobby world couldn't be loaded, disabling the plugin.");
            $this->getServer()->shutdown();
        }

        $this->registerListeners(
            [
                new LobbyListener(),
                new PlayerListener()
            ]
        );
    }

    /**
     * @param array $listeners
     * @return void
     */
    private function registerListeners(array $listeners): void
    {
        foreach ($listeners as $listener) {
            $this->getServer()->getPluginManager()->registerEvents($listener, self::getInstance());
        }
    }

    /**
     * @return void
     */
    public function onDisable(): void
    {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $player->transfer(BasicUtils::IP);
        }
    }
}