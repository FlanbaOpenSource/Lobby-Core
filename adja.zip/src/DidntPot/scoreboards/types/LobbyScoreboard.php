<?php

namespace DidntPot\scoreboards\types;

use DidntPot\scoreboards\Scoreboard;
use DidntPot\utils\BasicUtils;

class LobbyScoreboard extends Scoreboard
{
    /**
     * @return string[]
     */
    public function getLines(): array
    {
        return [
            " §eOnline: {WHITE}" . BasicUtils::getLobbyPlayers(true),
            " §eTB: 69 (Nice)",
            " §eRank: {WHITE}N/A",
            " §fOpen Beta!"
        ];
    }
}