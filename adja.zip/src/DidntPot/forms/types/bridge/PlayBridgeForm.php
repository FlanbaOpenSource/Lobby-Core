<?php

namespace DidntPot\forms\types\bridge;

use EasyUI\element\Button;
use EasyUI\variant\SimpleForm;
use paroxity\portal\Portal;
use pocketmine\player\Player;

class PlayBridgeForm extends SimpleForm
{
    public function __construct()
    {
        parent::__construct("Play Bridge");
    }

    /**
     * @return void
     */
    protected function onCreation(): void
    {
        $this->addButton(new Button("Solo (1 vs 1)", null, function (Player $player) {
            Portal::getInstance()->transferPlayer($player, "bridge", "solo-1", null);
        }));

        $this->addButton(new Button("Duo (2 vs 2)", null, function (Player $player) {
            Portal::getInstance()->transferPlayer($player, "bridge", "duos-1", null);
        }));

        $this->addButton(new Button("Trios (3 vs 3)", null, function (Player $player) {
            Portal::getInstance()->transferPlayer($player, "bridge", "trios-1", null);
        }));

        $this->addButton(new Button("Squad (4 vs 4)", null, function (Player $player) {
            Portal::getInstance()->transferPlayer($player, "bridge", "squads-1", null);
        }));
    }
}