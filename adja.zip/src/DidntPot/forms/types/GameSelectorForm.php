<?php

namespace DidntPot\forms\types;

use DidntPot\forms\types\bridge\PlayBridgeForm;
use EasyUI\element\Button;
use EasyUI\variant\SimpleForm;
use pocketmine\player\Player;

class GameSelectorForm extends SimpleForm
{
    public function __construct()
    {
        parent::__construct("Game Selector");
    }

    /**
     * @return void
     */
    protected function onCreation(): void
    {
        $this->addButton(new Button("Bridge", null, function (Player $player) {
            $player->sendForm(new PlayBridgeForm());
        }));
    }
}