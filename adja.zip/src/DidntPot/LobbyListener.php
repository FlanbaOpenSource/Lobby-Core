<?php

namespace DidntPot;

use DidntPot\utils\BasicUtils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\player\Player;

class LobbyListener implements Listener
{
    /**
     * @param EntityDamageEvent $ev
     * @return void
     */
    public function onEntityDamage(EntityDamageEvent $ev): void
    {
        $player = $ev->getEntity();

        if (!$player instanceof Player) return;

        switch ($ev->getCause()) {
            case EntityDamageEvent::CAUSE_DROWNING:
            case EntityDamageEvent::CAUSE_FALL:
            case EntityDamageEvent::CAUSE_BLOCK_EXPLOSION:
            case EntityDamageEvent::CAUSE_LAVA:
            case EntityDamageEvent::CAUSE_FIRE:
            case EntityDamageEvent::CAUSE_FIRE_TICK:
            case EntityDamageEvent::CAUSE_STARVATION:
            case EntityDamageEvent::CAUSE_CONTACT:
                $ev->cancel();
                break;

            case EntityDamageEvent::CAUSE_VOID:
                $player->teleport(BasicUtils::getLobbyWorld()->getSafeSpawn());
                break;
        }

        if ($ev instanceof EntityDamageByEntityEvent) {
            $ev->cancel();
        }
    }

    public function onBreak(BlockBreakEvent $event) {

        $event->cancel();

    }

    public function onCraft(CraftItemEvent $event) {
        $event->cancel();
    }
}